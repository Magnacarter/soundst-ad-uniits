
> short description of the bug / issue, provide more detail below.

====================================================================


###### `[  paste your jsfiddle link here  ]`  

use this jsfiddle to reproduce your bug: 
http://jsfiddle.net/simeydotme/fmo50w7n/ 
we will likely close your issue without it.


====================================================================


#### Steps to reproduce the problem

1. ...  
2. ...  


====================================================================


#### What is the expected behaviour?

...  


====================================================================


#### What is observed behaviour?

...  


====================================================================


#### More Details

- Which browsers/versions does it happen on?
- Which jQuery/Slick version are you using?
- Did this work before?




