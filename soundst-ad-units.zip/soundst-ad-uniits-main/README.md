##
Tailwind Docs
https://tailwindcss.com/docs/installation

##
Run Tailwind
npx tailwindcss -i ./src/input.css -o ./dist/output.css --watch